import React from 'react';
import './DashboardLoader.css';
const DashboardLoader = () => {
    return (
        <>
            <div className="lds-ring"><div></div><div></div><div></div><div></div></div>
        </>
    );
};

export default DashboardLoader;