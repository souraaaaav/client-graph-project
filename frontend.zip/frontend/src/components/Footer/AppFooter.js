import React from 'react'
import './Footer.css'
const AppFooter = () => {
    return (
        <footer>

            <hr />
            <hr />
            All rights reserved by cr3w

        </footer>
    )
}

export default AppFooter